import json
import os
import logging
import requests
from urllib.request import urlopen, Request
from urllib.parse import parse_qs

import post_message_to_slack

# lambda function
def lambda_handler(event, content):
    print(event)
    token = os.environ["GITHUB_ACCESS_TOKEN"]
    create_issue = {
    "title": "Found a bug",
    "body": "create test issue.", #issueの中身
    "assignee": "", #assigneeの設定
    # "milestone": "", #指定した番号のマイルストーンを設定
    "labels": [] #ラベルの指定
    }

    url = "http://api.github.com/repos/odrum428/create_github_issue_from_lambda/issues"

    requests.post(url, data=json.dumps(create_issue))

    # url = "http://api.github.com/repos/:user/:reponame/issues"

    # slackからの投稿を slack_input_text へ格納
    slack_input_text = str(event["event"]["text"])
    print(slack_input_text)

    bot_name = 'slack_tenki'
    msg = "slackとgithubが正しくつながってるよ！"

    response = {
    'statusCode': 200,
    'body': msg
    }

    return response
